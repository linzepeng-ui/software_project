function staffOperation() {
	window.location.assign("staff_operation.html");
}
function staffSetPersonalMsg() {
	window.location.assign("staff_setPersonalMsg.html");
}
function staffSalaryMsg() {
	window.location.assign("staff_SalaryMsg.html");
}
function staffResetPassword() {
	window.location.assign("staff_resetPassword.html");
}
function departmentOperation() {
	window.location.assign("department_operation.html");
}
function departmentSalaryMsg() {
	window.location.assign("department_salaryMsg.html");
}
function departmentOutSalaryTable() {
	window.location.assign("department_outSalaryTable.html");
}
function salaryOfficePersonalList() {
	window.location.assign("salaryOffice_personalList.html");
}
function salaryOfficeDepartmentList() {
	window.location.assign("salaryOffice_departmentList.html");
}
function administratorCodeRepare() {
	window.location.assign("administrator_codeRepare.html");
}
function administratorDataBankRepare() {
	window.location.assign("administrator_dataBankRepare.html");
}
